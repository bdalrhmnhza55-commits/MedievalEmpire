# Medieval Empire — Playable Prototype

A functional vertical-slice prototype of the grand-strategy/tactical concept.

## Run
Open `index.html` in a modern desktop browser.

## Controls
- WASD / Arrow keys: move camera
- Mouse wheel: strategic/tactical zoom
- Left click: select army/battalion/city
- Right click: issue movement order to selected army
- Space: pause/unpause
- F: formation toggle
- G: recruit a new commander
- K: kill selected army commander (prototype permadeath test)
- B: build/rebuild city defenses
- T: advance time / season
- R: spawn a disaster
- 1/2/3: select friendly armies

## Prototype systems
- 1,000+ simulated soldiers
- Battalion formations
- Commander stats and permadeath
- Morale/cohesion/supply
- Terrain and weather modifiers
- Seasons
- Cities and basic economy
- Physical caravans
- Bandits
- Basic combat
- Dynamic camera
- Performance-conscious canvas rendering

This is a prototype, not the final AAA renderer. The production target is Unreal Engine 5.8 + Mass Entity.
